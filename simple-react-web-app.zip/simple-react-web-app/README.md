# Simple React 18 App Built with Vite

Full Course [available on my YouTube Channel](https://www.youtube.com/@pH7Programming/videos) 🥳
